<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebd4cdd24de             |
    |_______________________________________|
*/
 namespace Pmpr\Module\DomainManager\Model; use Pmpr\Module\DomainManager\Container; class Model extends Container { public function mameiwsayuyquoeq() { Domain::symcgieuakksimmu(); Ownership::symcgieuakksimmu(); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f43d9ab4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\DomainManager\Model; use Pmpr\Module\DomainManager\Container; class Model extends Container { public function mameiwsayuyquoeq() { Domain::symcgieuakksimmu(); Ownership::symcgieuakksimmu(); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67235725c30bf             |
    |_______________________________________|
*/
 use Pmpr\Module\DomainManager\DomainManager; DomainManager::symcgieuakksimmu();

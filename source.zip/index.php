<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66af631561dc2             |
    |_______________________________________|
*/
 use Pmpr\Module\DomainManager\DomainManager; DomainManager::symcgieuakksimmu();
